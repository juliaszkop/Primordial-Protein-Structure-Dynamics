source leaprc.protein.ff19SB
#source leaprc.DNA.bsc1
#source leaprc.water.opc
#source leaprc.protein.ff19SB_modAA
mol = loadPDB peptide_noh.pdb
setBox mol vdw
#solvateoct mol OPCBOX 30.0
#addions mol Na+ 0
#addions mol Cl- 0
saveamberparm mol peptide.prmtop peptide.inpcrd
#savepdb mol draft_box.pdb
quit
