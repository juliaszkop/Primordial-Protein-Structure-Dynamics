#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import sys


def fix_pdb_atom_names(input_pdb, output_pdb):
    """
    Read a PDB file, correct known atom naming issues, and write a new PDB file.
    
    Currently fixes:
        CD  TRP -> CD1 TRP
        CD  ILE -> CD1 ILE
    """  
    # Define corrections as (atom_name, residue_name) -> new_atom_name
    corrections = {
        (" CD  ", "TRP"): " CD1 ",
        (" CD  ", "ILE"): " CD1 ",
        (" CD  ", "PHE"): " CD1 ",
        (" CD  ", "LEU"): " CD1 ",
        (" CD  ", "TYR"): " CD1 ",
    }
    with open(input_pdb, "r") as infile, open(output_pdb, "w") as outfile:
        for line in infile:
            if line.startswith(("ATOM", "HETATM")):
                atom_name = line[12:17]
                res_name = line[17:20]
                key = (atom_name, res_name)
                if atom_name[0] == "H":
                    continue
                if atom_name[1] == "H":
                    continue               
                if atom_name == " OC1 ":
                    continue
                if atom_name == " OC2 ":
                    continue
                if key in corrections.keys():
                    new_atom = corrections[key]
                    line = line[:12] + new_atom + line[17:]
            
            outfile.write(line)

input_file = sys.argv[1]

if not os.path.exists(input_file):
    sys.exit() 

fix_pdb_atom_names(input_file,"peptide_noh.pdb")
