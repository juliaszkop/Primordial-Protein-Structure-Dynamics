source leaprc.protein.ff19SB
#source leaprc.DNA.bsc1
#source leaprc.water.opc
#source leaprc.protein.ff19SB_modAA
mol = loadPDB peptide_noh.pdb
mol_capped = sequence { ACE mol NME }
check mol_capped
setBox mol_capped vdw
#solvateoct mol OPCBOX 30.0
#addions mol Na+ 0
#addions mol Cl- 0
saveamberparm mol_capped peptide.prmtop peptide.inpcrd
savepdb mol_capped peptide_test.pdb
quit
